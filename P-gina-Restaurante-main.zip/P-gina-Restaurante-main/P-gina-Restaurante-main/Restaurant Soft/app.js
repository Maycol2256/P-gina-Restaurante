const express = require('express');
const bodyParser = require('body-parser');
const mysql2 = require('mysql2/promise.js');
const app= express();

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
const db=mysql2.createPool({
    host: 'localhost',
    user: 'root',
    database: 'restaurante',

});
app.post('/insetar', async (req, res) => {
    const {Nombre_Mesero}=req.body
    const {Orden_Mesa,Orden_Propina}=req.body
    const {Nombre_Producto}=req.body
    try{
        const[rows2]=await db.query('INSERT INTO producto (Nombre_Producto) VALUES (?)', [Nombre_Producto]);
        console.log('Data inserted 3');
        const[rows1]=await db.query('INSERT INTO orden (Orden_Mesa, Orden_Propina) VALUES (?, ?)', [Orden_Mesa, Orden_Propina]);
        console.log('Data inserted 2');
        const[rows]=await db.query('INSERT INTO mesero (Nombre_Mesero) VALUES (?)', [Nombre_Mesero]);
        console.log('Data inserted 1');
    res.status(200).json({ message: 'Data inserted successfully' });
    }
    catch(err){
        console.log('Error',err);
    }
});
app.listen(3000, ()=> {
    console.log('Server is running on port 3000');
})